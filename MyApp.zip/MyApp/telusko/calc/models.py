from django.db import models

# Create your models here.





class Destination:
    alim_1: int
    satim_1: int
    alim_2: int
    satim_2: int
    alim_3: int
    satim_3: int
    alim_4: int
    satim_4: int
    alim_5: int
    satim_5: int