from django.shortcuts import render
from .models import Destination
# Create your views here.

from bs4 import BeautifulSoup as  bs
import requests
import re







dest1=Destination()

def denek(request):
 
    dest1.alim_1=1
    dest1.satim_1=2

   
   
    

def index(request):
    denek(request)
    return render(request, "index.html")

  

def result(request):
      if request.method == "POST":
          # denek(request)
           return render(request, "result.html",{"price":dest1})
   
