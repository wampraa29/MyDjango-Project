from bs4 import BeautifulSoup as  bs
import requests

import schedule
import time
import re


from .models import Knight_Online


def job():
    ByNoGame = {
    0:"Sirius", 
    1:"Vega",   
    2:"Altar",  
    3:"Olympia",
    4:"Ares",   
    5:"Diez",   
    6:"Gordion",
    7:"Rosetta",
    8:"Destan"

}
    KoPazar = {
    0:"Altar",  
    1: "Vega",   
    2: "Sirius",
    3: "Ares", 
    4: "Diez",
    5:"Gordion",
    6:"Rosetta",
    7:"Olympia",
    8:"Destan"

}

    YesilYurt = { 
    0:"Altar",
    1:"Sirius",
    2:"Vega",
    3:"Destan",
    4:"Rosetta",
    5:"Olympia",
    6:"Ares",
    7:"Diez",
    8:"Gordion"
}

    OyunFor = { 
    0:"Altar",
    1:"Vega",
    2:"Sirius",
    3:"Ares",
    4: "Destan",
    5:"Diez",
    6:"Gordion",  
    7: "Rosetta",
    8:"Olympia"
}

    GameSatis = {
    0:"Altar",
    1:"Vega",
    2:"Sirius",
    3:"Ares",
    4:"Diez",
    5:"Gordion",  
    6:"Destan",
    7:"Rosetta",
    8:"Olympia"
}


    KlassGame = {
    0:"Altar",
    1:"Vega",
    2:"Sirius",
    3:"Ares",
    4:"Diez",
    5:"Gordion",  
    6:"Destan",
    7:"Rosetta",
    8:"Olympia"
}

    BursaGB = {
    0:"Altar",
    1:"Vega",
    2:"Sirius",
    3:"Ares",
    4:"Diez",
    5:"Gordion",  
    6:"Destan",
    7:"Rosetta",
    8:"Olympia"
}
    KabasakalOnline = {
    0:"Altar",
    1:"Sirius",
    2:"Vega",
    3:"Destan",  
    4:"Rosetta",
    5:"Olympia",
    6:"Ares",
    7:"Diez",
    8:"Gordion"
}
    XGame = {
    0:"Sirius",
    1:"Altar",
    2:"Vega",
    3:"Olympia",  
    4:"Destan",
    5:"Gordion",
    6:"Diez",
    7:"Ares",
    8:"Rosetta"
}
   
    url_1="https://www.bynogame.com/Oyunlar/knight-online/gold-bar"
    html = requests.get(url_1).text
    soup = bs(html, "lxml")
    #Özetin bulunduğu element'in metin kısmını alıyoruz.

    a=soup.find_all('span', {'style':'font-size: 1.1em;'})

    content = []


    for li in a:
        content.append(li.getText())
    for i in range(9):
        #Knight_Online.objects.create(server_adi=ByNoGame[i],firma_adi="BynoGame",alim=float(content[i])/10,satim=float(content[i+1])/10)
        Knight_Online.objects.filter(server_adi=ByNoGame[i],firma_adi="BynoGame").update(satim=float(content[2*i])/10,alim=float(content[2*i+1])/10)
    #dest1=Destination()
   

    url_2="https://www.kopazar.com/knight-online-gold-bar"
    html = requests.get(url_2).text
    soup = bs(html, "lxml")
    #Özetin bulunduğu element'in metin kısmını alıyoruz.

    a=soup.find_all('b')
   
    content = []
    for li in a:
       content.append(li.getText())

    for i in range(9):
        #Knight_Online.objects.create(server_adi=KoPazar[i],firma_adi="KoPazar",alim=content[i],satim=content[i+1])
        Knight_Online.objects.filter(server_adi=KoPazar[i],firma_adi="KoPazar").update(alim=content[2*i],satim=content[2*i+1])
    
    try:
        url_3="https://www.yesilyurtgame.com/knight-online/gold-bar"
        html = requests.get(url_3).text
        soup = bs(html, "lxml")
        #Özetin bulunduğu element'in metin kısmını alıyoruz.

        c=soup.findAll(
               lambda tag:tag.name == "div" and
                len(tag.attrs) == 0 )

    
        soup = bs(str(c), "lxml")           
        z=[]
        for string in soup.stripped_strings:
            z.append(repr(string)) 
    
        x = re.findall(r"\b Alış Fiyatı : [-+]?([0-9]*\.[0-9]+|[0-9]+)", str(z))
        y = re.findall(r"\bSatış Fiyatı : [-+]?([0-9]*\.[0-9]+|[0-9]+)", str(z))
    
       
        for i in range(9):
            #Knight_Online.objects.create(server_adi=YesilYurt[i],firma_adi="YesilYurt",alim=x[i],satim=y[i])
            Knight_Online.objects.filter(server_adi=YesilYurt[i],firma_adi="YesilYurt").update(alim=x[i],satim=y[i])
    except:
        print("yok bisey")
        #for i in range(9):
            #Knight_Online.objects.create(server_adi=YesilYurt[i],firma_adi="YesilYurt",alim='-',satim='-')
            #Knight_Online.objects.filter(server_adi=YesilYurt[i],firma_adi="YesilYurt").update(alim="-",satim="-")

    url_4="https://www.oyunfor.com/knight-online/gb-gold-bar"
    html = requests.get(url_4).text
    soup = bs(html, "lxml")

    
    c=soup.find_all('span',{'class':'price'})

    a=soup.find_all('button',{'class':'btn bizeSatButton bizeSat'})
    soup = bs(str(a), "lxml")
    a=soup.find_all('span',{'class':'notranslate'})
    
    
    content=[]
    for li in a:
       content.append(li.getText())

    continent=[]
    for li in c:
       continent.append(li.getText())
    
    for i in range(9):
            #Knight_Online.objects.create(server_adi=OyunFor[i],firma_adi="OyunFor",alim=content[i],satim=continent[i+1])
            Knight_Online.objects.filter(server_adi=OyunFor[i],firma_adi="OyunFor").update(alim=content[i],satim=continent[i])
    

    content=[]
    servers=["altar","vega","sirius","ares","diez","gordion","destan","rosetta","olympia"]
   
    
    for i in servers:
        url="https://www.gamesatis.com/knight-online-goldbar/"+i+"-gb-gold-bar"
        html = requests.get(url).text
        soup = bs(html, "lxml")
        a=soup.findAll('div',{'class':'h4 mb-0'})
        content.append(a)
    t=len(a)    
   # print(content)
    temp =[]   
    for li in content:
        for lik in li:
            temp.append(lik.getText())
    if(t==2):
        for i in range(9):
                #print(temp)
                f=re.findall(r"[-+]?\d*\,\d+|\d+", temp[2*i])
                e=re.findall(r"[-+]?\d*\,\d+|\d+", temp[2*i+1])
                #Knight_Online.objects.create(server_adi=GameSatis[i],firma_adi="GameSatis",alim=f[0],satim=e[0])
                Knight_Online.objects.filter(server_adi=GameSatis[i],firma_adi="GameSatis").update(alim=f[0],satim=e[0])
    
    elif(t==1):
        for i in range(9):
                #print(temp)
                f=re.findall(r"[-+]?\d*\,\d+|\d+", temp[i])
                #Knight_Online.objects.create(server_adi=GameSatis[i],firma_adi="GameSatis",alim=f[0],satim=e[0])
                Knight_Online.objects.filter(server_adi=GameSatis[i],firma_adi="GameSatis").update(alim="+",satim=f[0])
    
   
     
    url_5="https://www.klasgame.com/knightonline/knight-online-gb-goldbar-premium-cash"
    html = requests.get(url_5).text
    soup = bs(html, "lxml")
    #Özetin bulunduğu element'in metin kısmını alıyoruz.
    d=soup.find_all('div',{"id":"urunler"})
    soup = bs(str(d), "lxml")
    a=soup.find_all('span',{"data-type":"price"})
    c=soup.find_all('span',{"data-type":"bizesat"})
   
    content = []
    continent = []
    for li in a:
       content.append(li.getText())
    for li in c:
       continent.append(li.getText())
   
    for i in range(9):
            #Knight_Online.objects.create(server_adi=KlassGame[i],firma_adi="KlassGame",alim=continent[i],satim=content[i])
            Knight_Online.objects.filter(server_adi=KlassGame[i],firma_adi="KlassGame").update(alim=continent[i],satim=content[i])
    
   
    servers=["altar","vega","sirius","ares","diez","gordion","destan","rosetta","olympia"]
   
    url_2="https://www.kabasakalonline.com/knight-online/knight-online-goldbar"
    html = requests.get(url_2).text
    soup = bs(html, "lxml")
    #Özetin bulunduğu element'in metin kısmını alıyoruz.
    a=soup.find_all('div',{"class":"product-list-a1"})
    soup = bs(str(a), "lxml")
    a=soup.find_all('span',{"data-type":"price"})
    c=soup.find_all('span',{"data-type":"bizesat"})
    
    content = []
    continent = []
    for li in a:
       content.append(li.getText())
    for li in c:
       continent.append(li.getText())
    for i in range(9):
            #Knight_Online.objects.create(server_adi=KabasakalOnline[i],firma_adi="KabasakalOnline",alim=continent[i],satim=content[i])
            Knight_Online.objects.filter(server_adi=KabasakalOnline[i],firma_adi="KabasakalOnline").update(alim=continent[i],satim=content[i])

    continent=[]
    content=[]
    for i in servers:
        url="https://www.bursagb.com/knight-online-gold/knight-online-"+i+"-10m-gold-bar"
        html = requests.get(url).text
        soup = bs(html, "lxml")
        a=soup.findAll('div',{'class':'ps-product__info'})
        soup = bs(str(a), "lxml")
        a=soup.findAll('p',{'class':'ps-product__price'})
        c=soup.findAll('a',{'onclick':'showSellModal()'})
        content.append(a)
        if not c:
            continent.append('-')
        else:
            continent.append(c)

    text=[]
    for li in content:
      for lik in li:
        text.append(lik.getText())   
    text2=[]
    for li in continent:
      for lik in li:
        try:
            text2.append(lik.getText(strip=True))   
        except:
            text2.append(lik)  
    
    for i in range(9):
            f=re.findall(r"[-+]?\d*\.\d+|\d+", text2[i])
            if not f:
                f.append(text2[i])
            #Knight_Online.objects.create(server_adi=BursaGB[i],firma_adi="BursaGB",alim=f[0],satim=text[i])
            Knight_Online.objects.filter(server_adi=BursaGB[i],firma_adi="BursaGB").update(alim=f[0],satim=text[i])
         
    headers = {
    'authority': 'www.xgame.com.tr',
    'x-anka-token': 'ecuihPPE4wHnpwTosN2EwRpFbwLJo3IOwdhVMnb2B9-o7y3xfUtIYwrhI0rbivBKrYcpZCl-OJBetwqdTtMeAmkrVKw1',
    'accept': 'application/json, text/plain, */*',
    'x-requested-with': 'XMLHttpRequest',
    'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'cors',
    'sec-fetch-dest': 'empty',
    'referer': 'https://www.xgame.com.tr/knight-online-gold-bar',
    'accept-language': 'tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7',
    'cookie': '__cfduid=dc132c604fad60c18d3eff3885f7a9ac81594836803; QW5rYS51c2VyLmxhbmd1=1; ASP.NET_SessionId=045gak1r0q2jm1acx3p4mjlq; QW5rYS51c2VyLmd1ZXN0=6eae1d46-a376-4665-b321-0c6eb34795ec; QW5rYS51c2VydmgwczV6=905e3071-d4d3-415b-a42d-fe1f56257f35; dmgwczV6bmZhYmNkZWZn=r1_Zjjzhd9PSvXur7fL_y_OxQGcNhzNw4E8-sMXSJC7nZpQtMeJN08F3HJGIN8UNaNEo6PTk9pgt0Iyc7AOjX0_P1q81; _ga=GA1.3.190341539.1594836792; _gid=GA1.3.1579906457.1594836792; __tawkuuid=e::xgame.com.tr::0YPt9ZRQKA6K+SJxB5n5dcnx6/P4maD9iaZIbS0aIeXnTHIzIdbw8T4qQuz+r5+T::2; cookieconsent_status=dismiss; _gat=1; TawkConnectionTime=0; _gat_application=1; _gat_softanka=1',
}

    response = requests.get('https://www.xgame.com.tr/plugin/misc.games.detail.page/api/getGameSubCategories/53', headers=headers).text


    x = re.findall(r"\bpriceValue:[-+]?([0-9]*\.[0-9]+|[0-9]+)", response.replace('\"',''))

    headers = {
    'authority': 'www.xgame.com.tr',
    'x-anka-token': 'VT3s-ZFcVGRyIbnznZowJJ4CczQvLoDu3zxp7V3dm_vpYW-m0GvT2DLNKLS1-SiH5Oh2HIxSsvy3S_0F4wBglg36Zak1',
    'accept': 'application/json, text/plain, */*',
    'x-requested-with': 'XMLHttpRequest',
    'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'cors',
    'sec-fetch-dest': 'empty',
    'referer': 'https://www.xgame.com.tr/gb-takas-usko',
    'accept-language': 'tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7',
    'cookie': '__cfduid=dc132c604fad60c18d3eff3885f7a9ac81594836803; QW5rYS51c2VyLmxhbmd1=1; ASP.NET_SessionId=045gak1r0q2jm1acx3p4mjlq; QW5rYS51c2VyLmd1ZXN0=6eae1d46-a376-4665-b321-0c6eb34795ec; QW5rYS51c2VydmgwczV6=905e3071-d4d3-415b-a42d-fe1f56257f35; dmgwczV6bmZhYmNkZWZn=r1_Zjjzhd9PSvXur7fL_y_OxQGcNhzNw4E8-sMXSJC7nZpQtMeJN08F3HJGIN8UNaNEo6PTk9pgt0Iyc7AOjX0_P1q81; _ga=GA1.3.190341539.1594836792; _gid=GA1.3.1579906457.1594836792; __tawkuuid=e::xgame.com.tr::0YPt9ZRQKA6K+SJxB5n5dcnx6/P4maD9iaZIbS0aIeXnTHIzIdbw8T4qQuz+r5+T::2; cookieconsent_status=dismiss; _gat=1; TawkConnectionTime=1594851079232',
}

    response = requests.get('https://www.xgame.com.tr/plugin/misc.games.detail.page/api/getGameSubCategories/124', headers=headers).text


    y = re.findall(r"\bpriceValue:[-+]?([0-9]*\.[0-9]+|[0-9]+)", response.replace('\"',''))

    for i in range(9):  
        #Knight_Online.objects.create(server_adi=XGame[i],firma_adi="XGame",alim=y[i],satim=x[i])
        Knight_Online.objects.filter(server_adi=XGame[i],firma_adi="XGame").update(alim=y[i],satim=x[i])   
   

from apscheduler.schedulers.background import BackgroundScheduler


sched = BackgroundScheduler()


sched.add_job(job, 'interval', seconds=60)
sched.start()
