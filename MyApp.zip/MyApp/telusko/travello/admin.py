from django.contrib import admin

# Register your models here.
from .models import Knight_Online

admin.site.register(Knight_Online)
