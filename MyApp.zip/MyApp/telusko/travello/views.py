from django.shortcuts import render
from .models import Destination
# Create your views here.

from bs4 import BeautifulSoup as  bs
import requests
import re

from .tasks import job

dest1=Destination()

from .models import Knight_Online

def denek(request):


    m = request.POST.get('num')


    #dest1=Destination()
    dest1.server_adi=m
    dest1.satim_1=(Knight_Online.objects.filter(server_adi=m,firma_adi="BynoGame"))[0].satim
    dest1.alim_1=(Knight_Online.objects.filter(server_adi=m,firma_adi="BynoGame"))[0].alim

 

    dest1.satim_2=(Knight_Online.objects.filter(server_adi=m,firma_adi="KoPazar"))[0].satim
    dest1.alim_2=(Knight_Online.objects.filter(server_adi=m,firma_adi="KoPazar"))[0].alim

    
    
    dest1.satim_3=(Knight_Online.objects.filter(server_adi=m,firma_adi="YesilYurt"))[0].satim
    dest1.alim_3=(Knight_Online.objects.filter(server_adi=m,firma_adi="YesilYurt"))[0].alim
  
    dest1.satim_4=(Knight_Online.objects.filter(server_adi=m,firma_adi="OyunFor"))[0].satim
    dest1.alim_4=(Knight_Online.objects.filter(server_adi=m,firma_adi="OyunFor"))[0].alim

    dest1.satim_5=(Knight_Online.objects.filter(server_adi=m,firma_adi="GameSatis"))[0].satim
    dest1.alim_5=(Knight_Online.objects.filter(server_adi=m,firma_adi="GameSatis"))[0].alim

    dest1.satim_6=(Knight_Online.objects.filter(server_adi=m,firma_adi="KlassGame"))[0].satim
    dest1.alim_6=(Knight_Online.objects.filter(server_adi=m,firma_adi="KlassGame"))[0].alim
     
   
    dest1.satim_7=(Knight_Online.objects.filter(server_adi=m,firma_adi="BursaGB"))[0].satim
    dest1.alim_7=(Knight_Online.objects.filter(server_adi=m,firma_adi="BursaGB"))[0].alim
        
    dest1.satim_8=(Knight_Online.objects.filter(server_adi=m,firma_adi="KabasakalOnline"))[0].satim
    dest1.alim_8=(Knight_Online.objects.filter(server_adi=m,firma_adi="KabasakalOnline"))[0].alim
   
    dest1.satim_9=(Knight_Online.objects.filter(server_adi=m,firma_adi="XGame"))[0].satim
    dest1.alim_9=(Knight_Online.objects.filter(server_adi=m,firma_adi="XGame"))[0].alim


def index(request):
    #denek(request)
    return render(request, "index.html")

  

def home(request):
      if request.method == "POST":
           denek(request)
           return render(request, "home.html",{"price":dest1})










