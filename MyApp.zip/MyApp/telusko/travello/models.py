from django.db import models

# Create your models here.



class Destination:
    server_adi:str
    alim_1: int
    satim_1: int
    alim_2: int
    satim_2: int
    alim_3: int
    satim_3: int
    alim_4: int
    satim_4: int
    alim_5: int
    satim_5: int
    alim_6: int
    satim_6: int
    alim_7: int
    satim_7: int
    alim_8: int
    satim_8: int
    alim_9: int
    satim_9: int


   # 56902
class Knight_Online(models.Model):
        server_adi = models.CharField(max_length=60)
        firma_adi  = models.CharField(max_length=60)
        alim =  models.CharField(max_length=60)
        satim =  models.CharField(max_length=60)
      